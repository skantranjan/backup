const { getAuditLog } = require('../controllers/controller.auditLogs');
const bearerTokenMiddleware = require('../middleware/middleware.bearer');

async function auditLogsRoutes(fastify, options) {
  // POST /audit-logs - Comprehensive audit log data retrieval
  fastify.post('/api/audit-logs', {
    schema: {
      body: {
        type: 'object',
        properties: {
          cm_code: { 
            type: 'string', 
            description: 'CM Code (required)'
          },
          period_id: { 
            type: 'string', 
            description: 'Period ID filter'
          },
          sku_code: { 
            type: 'string', 
            description: 'SKU Code filter'
          },
          component_code: { 
            type: 'string', 
            description: 'Component Code filter'
          },
          packaging_type: { 
            type: 'string', 
            description: 'Packaging Type filter'
          },
          is_active: { 
            type: 'boolean', 
            description: 'Active status filter'
          },
          limit: { 
            type: 'integer', 
            description: 'Number of records per page',
            default: 100,
            minimum: 1,
            maximum: 1000
          },
          offset: { 
            type: 'integer', 
            description: 'Page offset for pagination',
            default: 0,
            minimum: 0
          }
        },
        required: [] // cm_code is now optional
      },
      response: {
        200: {
          type: 'object',
          properties: {
            success: { type: 'boolean' },
            message: { type: 'string' },
            data: {
              type: 'object',
              properties: {
                records: { 
                  type: 'array',
                  items: { type: 'object' }
                },
                pagination: {
                  type: 'object',
                  properties: {
                    total: { type: 'integer' },
                    limit: { type: 'integer' },
                    offset: { type: 'integer' },
                    has_more: { type: 'boolean' },
                    current_page: { type: 'integer' },
                    total_pages: { type: 'integer' }
                  }
                },
                filters_applied: {
                  type: 'object',
                  properties: {
                    cm_code: { type: 'string' },
                    period_id: { type: 'string', nullable: true },
                    sku_code: { type: 'string', nullable: true },
                    component_code: { type: 'string', nullable: true },
                    packaging_type: { type: 'string', nullable: true },
                    is_active: { type: 'boolean', nullable: true }
                  }
                },
                query_summary: {
                  type: 'object',
                  properties: {
                    cm_code: { type: 'string' },
                    total_records: { type: 'integer' },
                    returned_records: { type: 'integer' },
                    query_executed_at: { type: 'string', format: 'date-time' }
                  }
                }
              }
            }
          }
        },
        400: {
          type: 'object',
          properties: {
            success: { type: 'boolean' },
            message: { type: 'string' }
          }
        },
        500: {
          type: 'object',
          properties: {
            success: { type: 'boolean' },
            message: { type: 'string' },
            error: { type: 'string' }
          }
        }
      }
    },
    preHandler: [bearerTokenMiddleware]
  }, getAuditLog);
}

module.exports = auditLogsRoutes;
