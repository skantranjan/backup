const { Pool } = require('pg');
require('dotenv').config();

// Extract database name from DB_URL
const dbName = process.env.DB_URL?.split('/')?.pop()?.split('?')[0];

const pool = new Pool({
  host: process.env.POSTGRES_HOST,
  port: parseInt(process.env.POSTGRES_PORT, 10),
  user: process.env.POSTGRES_USER,
  password: process.env.POSTGRES_PASSWORD,
  database: dbName,
  ssl: process.env.PGSSLMODE === 'require' ? { rejectUnauthorized: false } : false
});

pool.on('connect', () => {
  console.log('✅ Connected to the PostgreSQL database');
});

pool.on('error', (err) => {
  console.error('❌ Unexpected error on idle client', err);
  process.exit(-1);
});

module.exports = pool;
