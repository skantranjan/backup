const { DefaultAzureCredential } = require('@azure/identity');
const { SecretClient } = require('@azure/keyvault-secrets');

const keyVaultName = 'ch-eip-sdptl-kv1-devtest';
const url = `https://${keyVaultName}.vault.azure.net`; //"https://ch-eip-sdptl-kv1-devtest.vault.azure.net"

const credential = new DefaultAzureCredential();
const client = new SecretClient(url, credential);

const secretNames = ['PGHOST', 'PGPORT', 'PGUSER', 'PGPASSWORD', 'PGDATABASE'];

async function loadSecrets() {
  try {
    for (const name of secretNames) {
      console.log(`Loading secret: ${name}`);
      const secret = await client.getSecret(name);
      process.env[name] = secret.value;
      console.log(`Secret ${name} loaded successfully`);
    }
  } catch (err) {
    console.error('Error loading secrets from Azure Key Vault:', err);
    process.exit(1);
  }
}

module.exports = loadSecrets;
