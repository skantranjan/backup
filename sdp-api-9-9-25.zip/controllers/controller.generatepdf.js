const axios = require('axios');
const FormData = require('form-data');
const { BlobServiceClient } = require('@azure/storage-blob');
const { DefaultAzureCredential } = require('@azure/identity');
const https = require('https');
const pool = require('../config/db.config');

const generatepdf = async (request, reply) => {
  try {
    console.log('=== API CALL STARTED ===');
    console.log('Request isMultipart:', request.isMultipart());

    // Check if file is uploaded - access from request.body since multipart plugin attaches it there
    const fileData = request.body.File;
    const signerEmail = request.body.email?.value || request.body.email; // Get email value from UI
    const cmCode = request.body.cm_code?.value || request.body.cm_code; // Get CM code from UI
    const period = request.body.period?.value || request.body.period; // Get period from UI
    
    // Safe logging without circular references
    if (fileData) {
      console.log('File data received:', {
        filename: fileData.filename || 'unknown',
        mimetype: fileData.mimetype || 'unknown',
        bufferSize: fileData._buf ? fileData._buf.length : 0,
        hasFile: !!fileData.file
      });
    } else {
      console.log('No file data received');
    }
    
    // Safely log email without circular references
    if (signerEmail && typeof signerEmail === 'object' && signerEmail.value) {
      console.log('Signer email received:', signerEmail.value);
    } else if (typeof signerEmail === 'string') {
      console.log('Signer email received:', signerEmail);
    } else {
      console.log('Signer email received (raw):', JSON.stringify(signerEmail, null, 2));
    }
    
    if (!fileData || !fileData.file) {
      return reply.code(400).send({
        success: false,
        message: 'File is required',
        timestamp: new Date().toISOString()
      });
    }

    // Extract email value safely
    const emailValue = signerEmail?.value || signerEmail;
    
    if (!emailValue || typeof emailValue !== 'string' || !emailValue.includes('@')) {
      return reply.code(400).send({
        success: false,
        message: 'Valid signer email is required',
        timestamp: new Date().toISOString()
      });
    }

    // Validate CM code and period
    if (!cmCode || typeof cmCode !== 'string') {
      return reply.code(400).send({
        success: false,
        message: 'CM code is required',
        timestamp: new Date().toISOString()
      });
    }

    if (!period || typeof period !== 'string') {
      return reply.code(400).send({
        success: false,
        message: 'Period is required',
        timestamp: new Date().toISOString()
      });
    }

    // Step 1: Get Adobe Sign OAuth refresh token
    console.log('=== STEP 1: Getting OAuth Token ===');
    const refreshUrl = process.env['ADOBE-REFRESH-URL'];
    
    const requestData = {
      grant_type: 'refresh_token',
      client_id: process.env['ADOBE-CLIENT-ID'],
      client_secret: process.env['ADOBE-CLIENT-SECRET'],
      refresh_token: process.env['ADOBE-REFRESH-TOKEN']
    };

    // Get new access token with SSL bypass
    const tokenResponse = await axios.post(refreshUrl, requestData, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      httpsAgent: new https.Agent({
        rejectUnauthorized: false
      })
    });

    const accessToken = tokenResponse.data.access_token;
    console.log('OAuth Token received successfully');

    // Step 2: Upload file to Adobe Sign transient documents
    console.log('=== STEP 2: Uploading to Adobe Sign ===');
    const transientUrl = process.env['ADOBE-TRANSIENT-DOCS-URL'];
    
    // Create form data for file upload
    const formData = new FormData();
    
    // Get file details from the multipart data
    const filename = fileData.filename || 'document.pdf';
    const contentType = fileData.mimetype || 'application/pdf';
    const buffer = fileData._buf; // Use the buffer directly
    
    formData.append('File', buffer, {
      filename: filename,
      contentType: contentType
    });

    console.log('Uploading file:', filename, 'Content-Type:', contentType, 'Buffer size:', buffer.length);

    // Upload file using the new access token with SSL bypass
    const uploadResponse = await axios.post(transientUrl, formData, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        ...formData.getHeaders()
      },
      httpsAgent: new https.Agent({
        rejectUnauthorized: false
      })
    });

    console.log('File uploaded to Adobe Sign successfully');

    // Step 3: Create Adobe Sign agreement
    console.log('=== STEP 3: Creating Agreement ===');
    const agreementsUrl = process.env['ADOBE-AGREEMENTS-URL'];
    
    const agreementData = {
      "participantSetsInfo": [
        {
          "role": "SIGNER",
          "order": 1,
                "memberInfos": [
        {
          "email": emailValue
        }
      ]
        }
      ],
      "name": filename, // Use the uploaded filename
      "signatureType": "ESIGN",
      "fileInfos": [
        {
          "transientDocumentId": uploadResponse.data.transientDocumentId
        }
      ],
      "state": "IN_PROCESS"
    };

    console.log('Creating agreement for email:', emailValue);

    // Create agreement using the access token with SSL bypass
    const agreementResponse = await axios.post(agreementsUrl, agreementData, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      httpsAgent: new https.Agent({
        rejectUnauthorized: false
      })
    });

    const agreementId = agreementResponse.data.id;
    console.log('Agreement created successfully with ID:', agreementId);

    // Step 4: Save agreement details to database
    console.log('=== STEP 4: Saving to Database ===');
    let dbId = null;
    try {
      const status = "IN_PROCESS";
      const createdAt = new Date();

      console.log('Saving agreement to database:', {
        email: emailValue,
        agreement_id: agreementId,
        status: status,
        created_at: createdAt,
        cm_code: cmCode,
        periods: period
      });

      const insertQuery = `
        INSERT INTO public.agreements (email, agreement_id, status, created_at, cm_code, periods, adobe_status, updated_at, signed_pdf_url, blob_uploaded_at)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
        RETURNING id
      `;

      // Convert period to integer for database
      const periodInt = parseInt(period);
      if (isNaN(periodInt)) {
        throw new Error(`Invalid period value: ${period}. Period must be a number.`);
      }

      const insertResult = await pool.query(insertQuery, [
        emailValue,
        agreementId,
        status,
        createdAt,
        cmCode,
        periodInt, // Convert to integer
        'IN_PROCESS',
        createdAt,
        null, // signed_pdf_url will be updated later
        null   // blob_uploaded_at will be updated later
      ]);

      dbId = insertResult.rows[0].id;
      console.log('Agreement saved to database with ID:', dbId);

    } catch (dbError) {
      console.error('Database insertion failed:', dbError.message);
      // Continue with the workflow even if DB insertion fails
    }

    // Step 5: Upload file to Azure Blob Storage using proven working method
    console.log('=== STEP 5: Azure Blob Upload ===');
    let azureResult = null;
    try {
      // Use the same Azure configuration as addComponent
      const accountName = process.env['AZURE-STORAGE-ACCOUNT'];
      const containerName = process.env['AZURE-CONTAINER-NAME-ADOBE'];
      
      if (!accountName || !containerName) {
        throw new Error('Azure storage configuration is missing');
      }
      const blobUrl = `https://${accountName}.blob.core.windows.net`;
      
      console.log('Azure Configuration:', {
        accountName: accountName,
        containerName: containerName,
        blobUrl: blobUrl,
        environment: process.env['NODE-ENV'] || 'development'
      });

      // Use the same authentication method as addComponent
      let blobServiceClient;
      if (process.env['NODE-ENV'] === 'production' && process.env['AZURE-STORAGE-CONNECTION-STRING']) {
        // Use connection string for production
        console.log('Using Azure Storage Connection String');
        blobServiceClient = BlobServiceClient.fromConnectionString(process.env['AZURE-STORAGE-CONNECTION-STRING']);
      } else {
        // Use credential-based authentication (same as addComponent)
        console.log('Using Azure Credentials');
        const { AzureCliCredential } = require("@azure/identity");
        const credential = new AzureCliCredential();
        blobServiceClient = new BlobServiceClient(blobUrl, credential);
      }

      console.log('BlobServiceClient created successfully');
      
      // Get container client
      const containerClient = blobServiceClient.getContainerClient(containerName);
      console.log('Container client created for:', containerName);
      
      // Create a unique blob name with timestamp
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const blobName = `${timestamp}_${filename}`;
      
      console.log('Preparing to upload blob:', blobName);
      
      const blockBlobClient = containerClient.getBlockBlobClient(blobName);
      
      // Upload the file buffer to Azure Blob
      console.log('Starting blob upload...');
      const uploadBlobResponse = await blockBlobClient.upload(buffer, buffer.length, {
        blobHTTPHeaders: {
          blobContentType: contentType
        }
      });

      console.log('File uploaded to Azure Blob successfully');

      azureResult = {
        accountName: accountName,
        containerName: containerName,
        blobName: blobName,
        url: blockBlobClient.url,
        etag: uploadBlobResponse.etag
      };

      // Step 6: Update database with blob URL and upload timestamp
      if (dbId && azureResult.url) {
        console.log('=== STEP 6: Updating Database with Blob URL ===');
        try {
          const updateQuery = `
            UPDATE public.agreements 
            SET signed_pdf_url = $1, 
                blob_uploaded_at = $2, 
                adobe_status = $3,
                updated_at = $4
            WHERE id = $5
          `;
          
          const updateResult = await pool.query(updateQuery, [
            azureResult.url,
            new Date(),
            'BLOB_UPLOADED',
            new Date(),
            dbId
          ]);
          
          console.log('Database updated with blob URL successfully');
        } catch (updateError) {
          console.error('Database update failed:', updateError.message);
        }
      }

    } catch (azureError) {
      console.error('Azure Blob upload failed:', azureError.message);
      azureResult = {
        error: 'Azure Blob upload failed',
        message: azureError.message
      };
    }

    // Return success response with safe data
    console.log('=== API CALL COMPLETED SUCCESSFULLY ===');
    return reply.send({
      success: true,
      message: 'Complete workflow executed successfully',
      data: {
        oauth: {
          message: 'OAuth token refreshed successfully',
          expires_in: tokenResponse.data.expires_in || 3600
        },
        upload: {
          message: 'File uploaded to Adobe Sign successfully',
          transientDocumentId: uploadResponse.data.transientDocumentId
        },
        agreement: {
          message: 'Agreement created successfully',
          id: agreementId,
          name: filename
        },
        database: {
          message: dbId ? 'Agreement saved to database successfully' : 'Database insertion failed',
          email: emailValue,
          agreement_id: agreementId,
          status: "IN_PROCESS",
          cm_code: cmCode,
          periods: period,
          db_id: dbId,
          blob_url_updated: azureResult && azureResult.url ? true : false
        },
        azureBlob: azureResult
      },
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    // Log the error safely without circular references
    console.error('=== API CALL FAILED ===');
    console.error('Error details:', {
      message: error.message,
      code: error.code || 'UNKNOWN_ERROR',
      stack: error.stack ? 'Stack trace available' : 'No stack trace'
    });
    
    // Return safe error response
    return reply.code(500).send({
      success: false,
      message: 'Failed to process request',
      error: {
        message: error.message,
        code: error.code || 'UNKNOWN_ERROR'
      },
      timestamp: new Date().toISOString()
    });
  }
};

module.exports = {
  generatepdf
};
