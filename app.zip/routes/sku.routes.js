const { saveSkuController } = require('../controllers/controller.savesku');
const { ssoTokenMiddleware } = require('../middleware/middleware.sso');

async function skuRoutes(fastify, options) {
  // Protected route - requires SSO token
  fastify.post('/api/sku', {
    preHandler: ssoTokenMiddleware
  }, saveSkuController);
}

module.exports = skuRoutes; 