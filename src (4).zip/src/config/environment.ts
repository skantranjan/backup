// Environment configuration for different deployment stages
export interface EnvironmentConfig {
  API_BASE_URL: string;
  ORIGIN: string;
  IS_PRODUCTION: boolean;
}

// Development environment (localhost)
const devConfig: EnvironmentConfig = {
  API_BASE_URL: 'https://haleon-api-dev.apigee.net/Sustainibility-portal-channel/v1',
  ORIGIN: 'http://localhost:3000',
  IS_PRODUCTION: false
};

// Production environment (deployed server)
const prodConfig: EnvironmentConfig = {
  API_BASE_URL: '/api', // Use proxy in production
  ORIGIN: 'https://sustainability-data-portal.eip.dev.haleon.com',
  IS_PRODUCTION: true
};

// Determine which environment we're running in
const getEnvironment = (): EnvironmentConfig => {
  // Check if we're in production (deployed on server)
  if (window.location.hostname === 'sustainability-data-portal.eip.dev.haleon.com') {
    return prodConfig;
  }
  
  // Check for environment variables (useful for build-time configuration)
  if (process.env.REACT_APP_ENVIRONMENT === 'production') {
    return prodConfig;
  }
  
  // Default to development
  return devConfig;
};

export const ENV_CONFIG = getEnvironment();

// Log environment info in development
if (!ENV_CONFIG.IS_PRODUCTION) {
  console.log('🌍 Environment:', ENV_CONFIG);
}
